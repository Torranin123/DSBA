import sys
def read_numbers(in_path):
    numbers = set()
    fin = open(in_path,"r")
    for line in fin.readlines():
        line = line.strip()
        num = int(line)
        numbers.add(num)
    fin.close()
    return numbers
    
numbers1 = read_numbers(sys.argv[1])
numbers2 = read_numbers(sys.argv[2])
print(numbers1.intersection(numbers2))


