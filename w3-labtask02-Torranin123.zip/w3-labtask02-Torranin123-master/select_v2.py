import sys
try:
    inputfile = sys.argv[1:]
    index = 1
    for j in inputfile[1:]:
        inputfile[index] = int(j)
        index += 1
    def select(in_path):
        names = list()
        fin = open(in_path,"r")
        for line in fin.readlines():
            names.append(line[0:-2])
        fin.close()
        return names
    
    
    file1 = select(inputfile[0])
    for i in sys.argv[2:]:
        print(file1[int(i)-1])
except ValueError as e:
    print("Invalid line number specified:",e)
except FileNotFoundError as e:
    print("Unable to read from file:",e)